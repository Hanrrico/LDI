<?php 
    $server = "localhost";
    $user = "root";
    $password = "";
    $dbname = "bdagenda";
    $coon = mysqli_connect($server,$user,$password,$dbname);
?>